##' Conduct checking.
##'
##' @title check
##' @param x xxx
##' @param y yyy
##' @return aadfadsf
##' @export
a <- function(x,y)
{
    mysum <- x+y
    mysum
}
